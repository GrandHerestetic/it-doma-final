import "./App.css";
import Button from "./UI/button/button";
import Header from "./components/header/header";
import SubHeader from "./components/subHeader/subHeader";
import icon from "./assets/icon.jpeg";
import dowload from "./assets/dowload.svg";
import ProfileForm from "./components/profileForm/profileForm";
import NavigationBar from "./components/navigationBar/navigationBar";
import InputRainbow from "./UI/rainbowInput/rainbow";
import ButtonBig from "./UI/button_big/buttonBig";
import PasswordForm from "./components/passwordForm/passwordForm";

function App() {
  return (
    <div className="App">
      <Header />
      {/* <SubHeader />
      <div className="navigationBar">
        <Button text="Выбрать:" />
        <NavigationBar />
      </div> */}
      <ProfileForm />
      {/* <PasswordForm/> */}
      {/* <div>
        <table>
          <tr>
            <th>Место</th>
            <th>ФИО тренера</th>
            <th>Кол-во баллов</th>
            <th>Ранг</th>
            <th>Значок</th>
          </tr>
        </table>
      </div> */}
    </div>
  );
}

export default App;
