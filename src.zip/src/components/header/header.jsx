import React from "react";
import style from "./header.module.css";
import notification from "../../assets/notification.svg"
import rank from "../../assets/rank.svg"
import Link from "../../UI/links/link";
import logo from "../../assets/logoItDoma.svg";
import icon from "../../assets/icon.jpeg";

const Header = () => {
  return (
    <header className={style.Header}>
      <img src={logo} alt={style.Logo} />
      <Link text="Уроки" />
      <Link text="Информация" />
      <Link text="Баллы" />
      <Link text="Чат" />
      <Link text="Расписание" />
      <Link text="Домашнее задание" />
      <img src={notification} alt="Notification" />
      <img src={rank} alt="Rank" />
      <img src={icon} alt="Icon" className={style.icon} />
    </header>
  );
};

export default Header;
