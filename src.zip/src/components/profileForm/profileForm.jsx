import React from "react";
import style from "./profileForm.module.css";
import InputGray from "../../UI/inputGray/inputGray";
import icon from "../../assets/icon.jpeg";
import dowload from "../../assets/dowload.svg";
import InputRainbow from "../../UI/rainbowInput/rainbow";
import SelectRainbow from "../../UI/selectRainbow/selectRainbow";

const ProfileForm = () => {
  return (
    <div className={style.profileForm}>
      <div className={style.userData}>
        <div className="userImage">
          <img src={icon} alt="Icon" className="icon" />
          <form>
            <label className="iconUploader">
              <input type="file" />
              <img src={dowload} />
              <p>Заменить</p>
            </label>
          </form>
        </div>
      </div>
      <form>
        <InputGray title="Имя" placeholder="Введите свое имя" />
        <InputGray title="Фамилия" placeholder="Введите свою фамилию" />
        <InputGray title="Квалификация" placeholder="Эксперт супер пупер" />
        <SelectRainbow title="Пол"/>
        <InputRainbow title="Номер телефона" placeholder="Введите свой номер" />
      </form>
    </div>
  );
};

export default ProfileForm;
