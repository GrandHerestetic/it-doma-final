import React from "react";
import RadioButton from "../../UI/radioButton/radioButton";
import style from "./navigationBar.module.css";

const NavigationBar = () => {
  return (
    <form>
      <div className={style.radioInput}>
        <RadioButton name="navigation" id="profile" label="Профиль" />
        <RadioButton name="navigation" id="password" label="Пароль" />
      </div>
    </form>
  );
};

export default NavigationBar;
