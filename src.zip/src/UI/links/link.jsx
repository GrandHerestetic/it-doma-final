import React from "react";
import style from "./link.module.css"

const Link = (props) => {
    return(
        <a className={style.link}>{props.text}</a>
    )
}

export default Link