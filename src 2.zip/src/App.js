import "./App.css";

function App() {
  return (
    <div className="App">
      {/* <Homepage /> */}
      {/* <Profile/> */}
      {/* <PasswordPage/> */}
      {/* <RankTablePage/> */}
      {/* <TaskTablePage/> */}
    </div>
  );
}

export default App;
